$(function() {

	'use strict';
	
/*--------------------------------------------------------------
    Quote select box
--------------------------------------------------------------*/
    $('#discuss').selectmenu();

}); // end of document.ready