<!DOCTYPE html>
<html lang="en">
    <head>
        <!-- Meta Tags -->
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="Finance, Consulting and Business HTML Template">
        <meta name="keyword" content="your keyword goes to here">
        <meta name="author" content="themexriver">
        <!-- Page Title -->
        <title>DB Title Solution | Home</title>
        <!-- Favicon -->
        <link rel="icon" href="images/favicon.png">
        <!-- Icon fonts -->
        <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet">
        <link href="elegant_font/style.css" rel="stylesheet">
        <!-- Google fonts -->
        <!--<link href='https://fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
        <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,400italic,600,700,300' rel='stylesheet' type='text/css'>-->
        <!-- Bootstrap core CSS -->
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <!-- Revolution Slider -->
        <link  href="rev-slider/css/settings.css" rel="stylesheet" type="text/css"/>
        <link  href="rev-slider/css/layers.css" rel="stylesheet" type="text/css"/>
        <link  href="rev-slider/css/navigation.css" rel="stylesheet" type="text/css"/>
        <!-- Plugins for this template -->
        <link rel="stylesheet" href="css/animate.min.css">
        <link rel="stylesheet" href="css/jquery-ui.css">
        <link rel="stylesheet" href="css/owl.carousel.css">
        <link rel="stylesheet" href="css/owl.theme.css">
        <link rel="stylesheet" href="css/jquery.fancybox.css">
        <!-- Custom styles for this template -->
        <link href="css/custom-animation.css" rel="stylesheet">
        <link href="css/style.css" rel="stylesheet">
        <link href="css/responsive.css" rel="stylesheet">
        <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
        <!--[if lt IE 9]>
            <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
            <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->
        <!-- google map -->
        <!--<script src="http://maps.googleapis.com/maps/api/js"></script>-->
    </head>
    <body id="home">
        <!-- preloder -->
        <div class="preloder-wrapper">
            <div class="preloder-leftpart"></div>
            <div class="preloder-rightpart"></div>
            <div class="preloder"></div>
        </div>
        <!-- end of preloder -->

        <!-- header -->
        <header>
            <div class="top-bar">
                <div class="container">
                    <div class="row">
                        <div class="col col-md-8">
                            <ul class="nav">
                                <li><i class="icon_pin_alt"></i> 2423 S Alder St, Philadelphia, PA, 19148.</li>
                                <li><i class="icon_mobile"></i> 215-660-4022</li>
                                <li><i class="icon_clock_alt"></i> mon-sat  10.00 - 20.00</li>
                            </ul>                        
                        </div>

                        <div class="right-col col col-md-4">
                            <ul class="nav">
                                <li><i class="icon_phone"></i> Toll Free : 1-800-392-5102</li>                           
                            </ul>
                        </div>
                    </div>
                </div>
            </div> <!-- end of topbar -->

            <nav class="navbar">
                <div class="container">
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                        <a class="navbar-brand" href="#"><img src="images/logo.png" style="width:280px; height:70px;"></a>
                    </div>
                    <div id="navbar" class="collapse navbar-collapse navbar-right">
                        <ul class="nav navbar-nav">
                            <li><a href="index.html">Home</a></li>
                            <li><a href="aboutus.html">About Us</a></li>
                            <li><a href="services.html">Services</a></li>                      
                            <li><a href="contactus.html">Contact Us</a></li>
                        </ul>                    
                    </div>
                </div> <!-- end of container -->
            </nav> <!-- end of nav -->
        </header>
        <!-- end of header -->


        <!-- main-slider -->
        <div class="slider">
            <div class="rev_slider_wrapper">
                <div id="main-slider" class="rev_slider" data-version="5.0">
                    <ul>      
                        <li data-transition="fade"> 
                            <!-- MAIN IMAGE -->
                            <img src="images/slider/slider-1.jpg" alt width="1920" height="1280">
                            <div class="tp-caption maincaption layer-item"                             
                                 data-x="left" 
                                 data-hoffset="0" 
                                 data-y="top" 
                                 data-voffset="200"                             
                                 data-whitespace="normal"
                                 data-transform_idle="o:1;"          
                                 data-transform_in="y:-150px;opacity:0;s:1500;e:Power3.easeOut;" 
                                 data-transform_out="y:-150px;opacity:0;s:1000;e:Power2.easeInOut"
                                 data-width= "full"
                                 data-start="500">Service from the <span>expert</span></div>

                            <!-- LAYER NR. 2 -->
                            <div class="tp-caption para layer-item"
                                 data-x="left" 
                                 data-hoffset="0" 
                                 data-y="top" 
                                 data-voffset="275"                             
                                 data-whitespace="normal"
                                 data-transform_idle="o:1;"          
                                 data-transform_in="x:-150px;opacity:0;s:1000;e:Power3.easeOut;" 
                                 data-transform_out="x:-150px;opacity:0;s:700;e:Power2.easeInOut"
                                 data-width= "[630,630,630,full]"
                                 data-start="1300">Finance is the best template for your financial services. There are lots of option and opportunity to make a great website.</div>

                            <!-- LAYER NR. 3 -->
                            <div class="tp-caption more layer-item"
                                 data-x="left" 
                                 data-hoffset="0" 
                                 data-y="top" 
                                 data-voffset="355"                             
                                 data-whitespace="normal"
                                 data-transform_idle="o:1;"          
                                 data-transform_in="y:50px;opacity:0;s:2000;e:Power3.easeOut;" 
                                 data-transform_out="y:50px;opacity:0;s:1500;e:Power2.easeInOut"
                                 data-width= "153" 
                                 data-start="1300"><a href="#" class="btn btn-default theme-btn">Learn more <i class="arrow_right"></i></a></div>
                        </li>

                        <li data-transition="fade"> 
                            <!-- MAIN IMAGE -->
                            <img src="images/slider/slider-2.jpg" alt width="1920" height="1280">
                            <div class="tp-caption maincaption layer-item"                             
                                 data-x="left" 
                                 data-hoffset="0" 
                                 data-y="top" 
                                 data-voffset="200"                             
                                 data-whitespace="normal"
                                 data-transform_idle="o:1;"          
                                 data-transform_in="y:-150px;opacity:0;s:1500;e:Power3.easeOut;" 
                                 data-transform_out="y:-150px;opacity:0;s:1000;e:Power2.easeInOut"
                                 data-width= "full"
                                 data-start="500">Service from the <span>expert</span></div>

                            <!-- LAYER NR. 2 -->
                            <div class="tp-caption para layer-item"
                                 data-x="left" 
                                 data-hoffset="0" 
                                 data-y="top" 
                                 data-voffset="275"                             
                                 data-whitespace="normal"
                                 data-transform_idle="o:1;"          
                                 data-transform_in="x:-150px;opacity:0;s:1000;e:Power3.easeOut;" 
                                 data-transform_out="x:-150px;opacity:0;s:700;e:Power2.easeInOut"
                                 data-width= "[630,630,630,full]"
                                 data-start="1300">Finance is the best template for your financial services. There are lots of option and opportunity to make a great website.</div>

                            <!-- LAYER NR. 3 -->
                            <div class="tp-caption more layer-item"
                                 data-x="left" 
                                 data-hoffset="0" 
                                 data-y="top" 
                                 data-voffset="355"                             
                                 data-whitespace="normal"
                                 data-transform_idle="o:1;"          
                                 data-transform_in="y:50px;opacity:0;s:2000;e:Power3.easeOut;" 
                                 data-transform_out="y:50px;opacity:0;s:1500;e:Power2.easeInOut"
                                 data-width= "153" 
                                 data-start="1300"><a href="#" class="btn btn-default theme-btn">Learn more <i class="arrow_right"></i></a></div>
                        </li>
                    </ul>                          
                </div>
            </div>
        </div>
        <!-- end of main slider -->


        <!-- about-us -->
        <section class="about-us section-padding">
            <div class="container">
                <div class="row">
                    <div class="about col col-md-12">
                        <div class="section-title">                        
                            <h4>We bring value, innovation and growth to your business</h4>
                            <p>DB Title Solution USA is a global services provider offering knowledge processing services to Title companies seeking operational effectiveness, greater flexibility and lower operating costs, headquartered in McKinney, TX.</p>
                            <p>Our aim is to provide a level of satisfaction that is unparalleled in the Title Industry. We help our clients regain their focus on their core strength by "co-sourcing" to envisage cost efficiency and quality at the same time without compromising on delivery deadlines, Turnaround Time. Our approach is Simple, Significant and Systematic to ease our customer results through customer relations and leading technology.</p>
                            <p>DB Title Solution USA is a leading service provider of title and settlement services outsourcing solutions with domain expertise, technical excellence and unique background, help businesses succeed and be primed to explore the next level opportunity.</p>
                            <a href="#">Read more <i class="arrow_right"></i></a>
                        </div>
                    </div>               

                </div> <!-- end of row -->
            </div> <!-- end of container -->

            <div class="line">
                <div class="container"></div>
            </div>
        </section>
        <!-- end of about-us -->

        <!-- footer -->
        <footer>      
            <div class="copyright">
                <div class="container">
                    <div class="col col-sm-6">
                        <p>Copyright &copy;  2016 DB Title Solution, All Rights Reserved</p>
                    </div>
                    <div class="col col-sm-6">				
                        <p>Designed by <a href="#">DRN Definite Solutions Pvt Ltd.,</a></p>					
                    </div>
                </div> <!-- end of container -->
            </div> <!-- end of copyright -->
        </footer>
        <!-- end of footer -->


        <!-- All JavaScript files
        ================================================== -->
        <script src="js/jquery-1.11.3.min.js"></script>
        <script src="js/bootstrap.min.js"></script>

        <!-- Revolution Slider -->
        <script src="rev-slider/js/jquery.themepunch.tools.min.js"></script>
        <script src="rev-slider/js/jquery.themepunch.revolution.min.js"></script>

        <!-- Plugins for this template -->
        <script src="js/jquery-ui.js"></script>
        <script src="js/jquery.animateNumber.min.js"></script>
        <script src="js/jquery.appear.js"></script>
        <script src="js/owl.carousel.min.js"></script>
        <script src="js/progressbar.js"></script>
        <script src="js/jquery.fancybox.pack.js"></script>
        <script src="js/jquery.fancybox-media.js"></script>

        <!-- Custom script for this template -->
        <script src="js/index-script.js"></script>
        <script src="js/common-script.js"></script>

        <!-- Revolution slider extentions lode only local file system -->
        <script src="rev-slider/js/extensions/revolution.extension.actions.min.js"></script>
        <script src="rev-slider/js/extensions/revolution.extension.carousel.min.js"></script>
        <script src="rev-slider/js/extensions/revolution.extension.kenburn.min.js"></script>
        <script src="rev-slider/js/extensions/revolution.extension.layeranimation.min.js"></script>
        <script src="rev-slider/js/extensions/revolution.extension.migration.min.js"></script>
        <script src="rev-slider/js/extensions/revolution.extension.navigation.min.js"></script>
        <script src="rev-slider/js/extensions/revolution.extension.parallax.min.js"></script>
        <script src="rev-slider/js/extensions/revolution.extension.slideanims.min.js"></script>
        <script src="rev-slider/js/extensions/revolution.extension.video.min.js"></script>
    </body>
</html>
